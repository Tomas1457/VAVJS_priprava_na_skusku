        const pridajStudenta = (meno, priezvisko) => {
            fetch('http://localhost:8080/studenti',{
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({meno, priezvisko})
            }).then(() => {
                fetchStudenti();
            });
        };

        const butt = document.getElementById('add');
        butt.addEventListener('click',()=>{
            const meno = document.querySelector('input[name="meno"]').value;
            const priezvisko = document.querySelector('input[name="priezvisko"]').value;
            pridajStudenta(meno,priezvisko);
        });

        const fetchStudenti = () => {
            fetch('http://localhost:8080/studenti').then(data => data.json()).then(studenti => {
                const tableBody = document.querySelector('#studenti tbody');
                tableBody.innerHTML = '';
                studenti.forEach(student => {
                    const tr = document.createElement('TR');
                    tr.innerHTML = '<td>'+student.id+'</td><td>'+student.meno+'</td><td>'+student.priezvisko+'</td>';
                    tableBody.appendChild(tr);
                });
            });
        };
        fetchStudenti();

