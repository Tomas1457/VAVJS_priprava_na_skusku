import logo from './logo.svg';
import './App.css';

function Table(props) {
    let trStudenti =  props.studenti.map((student,index) => 
        <tr key={index}>
            <td>{student.id}</td>
            <td>{student.meno}</td>
            <td>{student.priezvisko}</td>
        </tr>
    );
    return (
        <table id="studenti">
            <thead><tr><th>id</th><th>meno</th><th>priezvisko</th></tr></thead>
            <tbody>
                { trStudenti }
            </tbody>
        </table>
    )
}

function App() {
  let studenti = [];
  fetch('http://localhost:8080/studenti').then(data => data.json()).then(st => {
    studenti = st;
  });
  return (
    <div className="App">
      <header className="App-header">
        <h1> Studenti </h1>
      </header>
      <main>
        <Table studenti={studenti} />
      </main>
    </div>
  );
}

export default App;
