const http = require('http');
const fs = require('fs');
const pg = require('pg');

const httpPort = 80;

let client = null;
(()=>{
    let icap = 30;
    let ival = setInterval(async ()=>{
        console.log('trying to connect to db');
        client = new pg.Client({
            user: 'postgres',
            password: 'postgres',
            host: 'db',
            port: 5432,
            database: 'studenti'
        });
        await client.connect().then(()=>{
            clearInterval(ival);
            console.log('connected to db');
        }).catch(()=>{});
        icap--;
        if(icap <= 0) {
            clearInterval(ival);
            console.error('failed');
        }
    },1000);
})();

const server = http.createServer(async (req,res)=>{
    console.log(`
        got request ${req.url}
    `); 
    if(req.url === '/studenti' && req.method === 'GET') {
        const studenti = await client.query('SELECT * FROM studenti;')
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(studenti.rows));
    }
    else if(req.url === '/studenti' && req.method === 'POST') {
        let chunks = '';
        req.on('data',(d) => {
            chunks += d.toString();
        });
        req.on('end',()=>{
            const student = JSON.parse(chunks);
            const q = 'INSERT INTO studenti (meno,priezvisko) VALUES (\''+student.meno+'\',\''+student.priezvisko+'\');';
            client.query(q);
            res.statusCode = 200;
            res.setHeader('Content-Type','application/json');
            res.end(JSON.stringify({message: 'ok'}));
        });
    }
    else {
        // BAAAD
        res.statusCode = 400;
        res.setHeader('Content-Type','text/plain');
        res.end('no, just no');
    }
});

server.listen(httpPort, ()=>{
    console.log('server is listening');
});
