console.log('yes working');

const socket = new WebSocket('ws://localhost:8082');
socket.addEventListener('open',(ev)=>{
    console.log('connection open');
});
socket.addEventListener('message',(ev)=>{
    const out = document.getElementById('out');
    out.innerText = ev.data;
});

const but = document.getElementById('send');
but.addEventListener('click',()=>{
    const inp = document.getElementById('in');
    socket.send(inp.value);
});
