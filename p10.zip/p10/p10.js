const f = (a,b) => {
    c = a + 1;
    return b+c;
}

console.log(f(4,1));
