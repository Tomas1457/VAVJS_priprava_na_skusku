# eshop

## routes
/produkty -> all produkty
/produkty/7 -> all info about produkt with id 7
/pouzivatelia
/pouzivatelia/7 -> all info about pouzival with id 7
/objednavky - > all objednavky
/objednavky/7 -> all info about ...

## DB
pouzivatelia
------------
id (auto increment)
meno
priezvisko
adresa
...

produkty
--------
id (auto increment)
nazov
popis
ceny
obrazok

objednavky
----------
id (auto increment)
prodid
userid


? kto si objednal auto
