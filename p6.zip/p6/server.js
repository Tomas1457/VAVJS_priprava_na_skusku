const http = require('http');
const fs = require('fs');
const pg = require('pg');

const httpPort = 80;

let client = null;
(async()=>{
    client = new pg.Client({
        user: 'postgres',
        password: 'postgres',
        host: 'db',
        port: 5432,
        database: 'eshop',
    })
    await client.connect();
})();

const server = http.createServer(async (req,res)=>{
    /// ...
    if(req.url === '/' || req.url === '/index.html') {
        const f = fs.readFileSync('public/index.html','utf-8'); 
        res.statusCode = 200;
        res.setHeader('Content-Type','text/html');
        res.end(f);
    }
    else if(req.url === '/tables.html') {
        const f = fs.readFileSync('public/tables.html','utf-8'); 
        res.statusCode = 200;
        res.setHeader('Content-Type','text/html');
        res.end(f);
    }
    else if(req.url === '/client.js') {
        const f = fs.readFileSync('public/client.js','utf-8'); 
        res.statusCode = 200;
        res.setHeader('Content-Type','application/javascript');
        res.end(f);
    }
    else if(req.url === '/objednavky.html') {
        const f = fs.readFileSync('public/objednavky.html','utf-8'); 
        res.statusCode = 200;
        res.setHeader('Content-Type','text/html');
        res.end(f);
    }
    else if(req.url === '/objednavky' && req.method === 'GET') {
        const orders = await client.query('SELECT * FROM objednavky;')
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(orders.rows));
    }
    else if(req.url === '/objednavky' && req.method === 'POST') {
        console.log('[POST] /objednavky');
        let chunks = '';
        req.on('data',(d) => {
            chunks += d.toString();
        });
        req.on('end',()=>{
            console.log('[POST] /objednavky end');
            const objednavka = JSON.parse(chunks);
            console.log('[POST] /objednavky '+chunks);
            client.query('INSERT INTO objednavky (userid,prodid) VALUES ('+objednavka.userid+','+objednavka.prodid+');');
            res.statusCode = 200;
            res.setHeader('Content-Type','application/json');
            res.end(JSON.stringify({message: 'ok'}));
        });
    }
    else if(req.url.indexOf('/objednavky/') >= 0) {
        const id = req.url.split('/')[2];
        const orders = await client.query('SELECT * FROM objednavky WHERE id='+id+';')
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(orders.rows[0]));
    }
    else if(req.url === '/pouzivatelia') {
        const users = await client.query('SELECT * FROM pouzivatelia;')
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(users.rows));
    }
    else if(req.url.indexOf('/pouzivatelia/') >= 0) {
        const id = req.url.split('/')[2];
        const users = await client.query('SELECT * FROM pouzivatelia WHERE id='+id+';')
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(users.rows[0]));
    }
    else if(req.url === '/produkty') {
        const prods = await client.query('SELECT * FROM produkty;')
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(prods.rows));
    }
    else if(req.url.indexOf('/produkty/') >= 0) {
        const id = req.url.split('/')[2];
        const prods = await client.query('SELECT * FROM produkty WHERE id='+id+';')
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(prods.rows[0]));
    }
    else if(req.url === '/ktoauto') {
        client.query('SELECT * FROM produkty;',(err1,produkty) => {
            let aid = -1;
            produkty.rows.forEach(produkt => {
                if(produkt.name === 'auto') aid = produkt.id;
            });
            if(aid >= 0) {
                client.query('SELECT * FROM objednavky;', (err2, objednavky) => {
                    let uid = -1;
                    objednavky.rows.forEach(objednavka => {
                        if(objednavka.prodid === aid) uid = objednavka.userid;
                    });
                    if(oid >= 0) {
                        client.query('SELECT * FROM pouzivatelia;', (err3, pouzivatelia) => {
                            pouzivatelia.rows.forEach(pouzivatel => {
                                if(pouzivatel.id === uid) console.log('auto si objednal '+pouzivatel.name);
                            });
                        });
                    }
                });
            }
        });

        const produkty = await client.query('SELECT * FROM produkty;');
        let aid = -1;
        produkty.row.forEach(produkt => {
            if(produkt.name === 'auto') aid = produkt.id;
        });
        const objednavky = await client.query('SELECT * FROM objednavky;');
        let uid = -1;
        objednavky.rows.forEach(objednavka => {
            if(objednavka.prodid === aid) uid = objednavka.userid; 
        });
        const pouzivatelia = await client.query('SELECT * FROM pouzivatelia;');
        pouzivatelia.rows.forEach(pouzivatel => {
            if(pouzivatel.id === uid) console.log('auto si objednal '+pouzivatel.name);
        });


        const [rodukty, objednavky, pouzivatelia] = Promise.all(getProdukty, getObjednavky, getPouzivatelia)

        const p1 = () => {
            return new Promise((resolve,reject) => {
                // pending, resolved, rejected
                setTimeout(()=>{resolve(5);},5000);
                setTimeout(()=>{reject(-1);},2000);
            });
        });

        const res = await p1();
        p1().then(d => console.log(d)).catch(err => console.log(err));

        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.end(JSON.stringify(prods.rows));
    }
    else {
        // BAAAD
        res.statusCode = 400;
        res.setHeader('Content-Type','text/plain');
        res.end('no, just no');
    }
});

server.listen(httpPort, ()=>{
    console.log('server is listening');
});


