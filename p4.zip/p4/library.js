let i = 0;
const f = () => {return i++;}

module.exports = f;

