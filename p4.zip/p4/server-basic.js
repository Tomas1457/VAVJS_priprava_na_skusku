const http = require('http');
const fs = require('fs');

const hostname = '127.0.0.1';
const port = 8080;

const server = http.createServer((req,res)=>{
    console.log('got request');
    if(req.url === '/' || req.url === '/index.html') {
        const file = fs.readFileSync('public/index.html','utf-8');
        res.statusCode = 200;
        res.setHeader('Content-Type','text/html');
        res.end(file);
    }
    else if(req.url === '/data') {
        if(req.method === 'POST') {
            let chunk = '';
            req.on('data',(data) => {
                chunk += data.toString()
            });
            req.on('end',() => {
                let json = {};
                try { json = JSON.parse(chunk); } catch(e) {}
                res.statusCode = 200;
                res.setHeader('Content-Type','application/json');
                res.end(JSON.stringify({"result": json.input+1}));
            });
        }
    }
    else {
        res.statusCode = 500;
        res.setHeader('Content-Type','text/plain');
        res.end('Error');
    }
});

server.listen(port,()=>{
    console.log('server listening on '+hostname+':'+port);
});
