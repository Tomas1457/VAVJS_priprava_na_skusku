const express = require('express');
const app = express();

const f = require('./library.js');

const port = 8080;

app.use(express.static('public'));
app.use(express.json());

app.post('/data',(req,res)=>{
    res.send(JSON.stringify({result: f()}));
});
app.listen(port,()=>{
    console.log('server listening on port '+port);
});



// tabulka OBJEDNAVKY
- id osoby
- id objednavky
- [ ] id produktov

// tabulka OSOBY
- id osoby
- meno
- priezvisko
- adresa

// tabulka PRODUKTY
- id produktu
- nazov produkty
- popis produktu
- obrazok produktu...


// kto si objednal "cajnik"?
- ? ake ma id zaznam s menom "cajnik" v tabuke PRODUKTY -> getIdProdukt('cajnik') -> 4
- ? ktore objednavky maju v [ ] id produktov id "cajniku" -> getObjednavky(4) -> [ ] objednavky
- ? ktore osoby mali tieto objednavky -> getOsoby([ ] objednavky) -> [ ] osoby

